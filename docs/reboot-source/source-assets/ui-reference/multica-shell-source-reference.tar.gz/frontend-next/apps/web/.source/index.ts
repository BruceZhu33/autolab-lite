// @ts-nocheck -- skip type checking
import * as useCases_3 from "../content/use-cases/auto-data-analysis.zh.mdx?collection=useCases&hash=1789446675000"
import * as useCases_2 from "../content/use-cases/auto-data-analysis.ko.mdx?collection=useCases&hash=1789446675000"
import * as useCases_1 from "../content/use-cases/auto-data-analysis.ja.mdx?collection=useCases&hash=1789446675000"
import * as useCases_0 from "../content/use-cases/auto-data-analysis.en.mdx?collection=useCases&hash=1789446675000"
import { _runtime } from "fumadocs-mdx/runtime/next"
import * as _source from "../source.config"
export const useCases = _runtime.docs<typeof _source.useCases>([{ info: {"path":"auto-data-analysis.en.mdx","fullPath":"content/use-cases/auto-data-analysis.en.mdx"}, data: useCases_0 }, { info: {"path":"auto-data-analysis.ja.mdx","fullPath":"content/use-cases/auto-data-analysis.ja.mdx"}, data: useCases_1 }, { info: {"path":"auto-data-analysis.ko.mdx","fullPath":"content/use-cases/auto-data-analysis.ko.mdx"}, data: useCases_2 }, { info: {"path":"auto-data-analysis.zh.mdx","fullPath":"content/use-cases/auto-data-analysis.zh.mdx"}, data: useCases_3 }], [])