// source.config.ts
import { defineDocs, defineConfig } from "fumadocs-mdx/config";
import { z } from "zod";
var dateString = z.preprocess(
  (v) => v instanceof Date ? v.toISOString().slice(0, 10) : v,
  z.string()
);
var useCaseFrontmatterSchema = z.looseObject({
  title: z.string(),
  description: z.string().optional(),
  hero_image: z.string(),
  updated_at: dateString,
  category: z.string().optional()
});
var useCases = defineDocs({
  dir: "content/use-cases",
  docs: {
    schema: useCaseFrontmatterSchema
  }
});
var source_config_default = defineConfig({
  mdxOptions: {}
});
export {
  source_config_default as default,
  useCases
};
