"use client";

import { useMemo } from "react";
import { CoreProvider } from "@multica/core/platform";
import { createBrowserCookieLocaleAdapter } from "@multica/core/i18n/browser";
import type { LocaleResources, SupportedLocale } from "@multica/core/i18n";
import { useWelcomeStore } from "@multica/core/onboarding";
import { installFixtureFetch } from "@autolab/research/fixture";
import packageJson from "../package.json";
import { WebNavigationProvider } from "@/platform/navigation";
import { SidecarInvalidationBridge } from "@/components/sidecar-invalidation-bridge";
import { WebScrollRestorationProvider } from "@/platform/scroll-restoration";
import {
  setLoggedInCookie,
  clearLoggedInCookie,
} from "@/features/auth/auth-cookie";
import { detectWebOS } from "@/platform/client-os";
import { useUserLocaleSyncEnabled } from "@/platform/user-locale-sync";

// Legacy token in localStorage → keep this session in token mode so users who
// logged in before the cookie-auth migration stay authed. They migrate to
// cookie mode on their next logout/login cycle (logout clears multica_token).
// Sunset: once telemetry shows <1% of sessions still carry multica_token,
// delete this branch and hard-code `cookieAuth` — the localStorage token is
// XSS-exposed and is the exact thing the cookie migration exists to remove.
function hasLegacyToken(): boolean {
  if (typeof window === "undefined") return false;
  try {
    return Boolean(window.localStorage.getItem("multica_token"));
  } catch {
    return false;
  }
}

// Derive WebSocket URL from the page origin so self-hosted / LAN deployments
// work without an explicit runtime wsUrl. The Next.js runtime proxy handles
// /ws -> backend when the deployment keeps WebSockets same-origin.
function deriveWsUrl(): string | undefined {
  if (typeof window === "undefined") return undefined;
  const proto = window.location.protocol === "https:" ? "wss:" : "ws:";
  return `${proto}//${window.location.host}/ws`;
}

// Build-time version preferred (CI sets NEXT_PUBLIC_APP_VERSION to a git tag
// or sha so different deploys are distinguishable in server logs); fall back
// to the package.json version so local dev still reports something useful.
const WEB_VERSION =
  process.env.NEXT_PUBLIC_APP_VERSION || packageJson.version || "dev";

export function WebProviders({
  children,
  locale,
  resources,
  apiBaseUrl,
  wsUrl,
}: {
  children: React.ReactNode;
  locale: SupportedLocale;
  resources: Record<string, LocaleResources>;
  apiBaseUrl?: string;
  wsUrl?: string;
}) {
  // AutoLab fixture 模式（v0.3 Phase 1）：在 CoreProvider 发出任何请求前
  // 安装 FixtureResearchPlatform，用内存数据替代 Multica server。
  if (process.env.NEXT_PUBLIC_AUTOLAB_FIXTURE === "1") {
    installFixtureFetch();
  }
  const cookieAuth = !hasLegacyToken();
  const syncUserLocale = useUserLocaleSyncEnabled();
  // Stable identity reference so downstream effects keyed on it don't see a
  // new object on every parent render.
  const identity = useMemo(
    () => ({ platform: "web", version: WEB_VERSION, os: detectWebOS() }),
    [],
  );
  const localeAdapter = useMemo(() => createBrowserCookieLocaleAdapter(), []);
  return (
    <CoreProvider
      apiBaseUrl={apiBaseUrl}
      wsUrl={wsUrl || deriveWsUrl()}
      cookieAuth={cookieAuth}
      onLogin={setLoggedInCookie}
      onLogout={() => {
        // welcome-store holds the transient post-onboarding signal. Must
        // clear on logout so user B logging into the same browser doesn't
        // inherit user A's signal and have <WelcomeAfterOnboarding /> fire
        // listAgents / createIssue against a workspace user B doesn't even
        // belong to. The store's own docstring promises this reset; this
        // is where it gets wired.
        useWelcomeStore.getState().reset();
        clearLoggedInCookie();
      }}
      identity={identity}
      locale={locale}
      resources={resources}
      localeAdapter={localeAdapter}
      syncUserLocale={syncUserLocale}
    >
      <SidecarInvalidationBridge />
      <WebNavigationProvider>
        <WebScrollRestorationProvider>{children}</WebScrollRestorationProvider>
      </WebNavigationProvider>
    </CoreProvider>
  );
}
