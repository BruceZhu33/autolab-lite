import { queryOptions } from "@tanstack/react-query";
import { api } from "../api";
import {
  BUILT_IN_STATUS_CATEGORY,
  BUILT_IN_STATUS_LABEL,
  BUILT_IN_STATUS_ORDER,
  STATUS_CONFIG,
  STATUS_ORDER,
} from "../issues/config";
import { normalizeIssueStatusCategory } from "../issues/config/status";
import type { BuiltInIssueStatus, IssueStatusCategory, IssueStatusEntry } from "../types";

/**
 * The workspace issue status catalog (MUL-6243).
 *
 * A workspace always has seven built-in statuses and may define custom ones.
 * Every status belongs to one of four lifecycle categories used for grouping
 * and presentation. Concrete status behavior remains keyed by status on the
 * server and is deliberately not inferred from the category.
 */

export const issueStatusKeys = {
  all: (wsId: string) => ["issue-statuses", wsId] as const,
  list: (wsId: string) => [...issueStatusKeys.all(wsId), "list"] as const,
};

export function issueStatusListOptions(wsId: string) {
  return queryOptions({
    queryKey: issueStatusKeys.list(wsId),
    // ARCHIVED entries included on purpose. Archiving retires a status from
    // future assignment but leaves existing issues on it, and those issues must
    // keep their real name, color and category. Dropping archived rows here
    // would degrade them to a raw key with a guessed category. Pickers use
    // `activeStatuses`, which excludes them. (MUL-6243)
    queryFn: () => api.listIssueStatuses(true),
    select: (data) => data.statuses,
    // The catalog changes only when an admin edits it, which is rare, so a
    // generous stale time keeps this off the critical path of every render
    // that needs a status label.
    staleTime: 5 * 60_000,
  });
}

/**
 * A resolved view over the catalog. Every lookup falls back to something
 * renderable, because an issue can legitimately carry a status this client has
 * not heard of: a status created moments ago in another session, or one whose
 * catalog fetch has not landed yet.
 */
export interface IssueStatusCatalog {
  /**
   * Every status in display order, ARCHIVED INCLUDED, so an issue left on an
   * archived status still resolves to its real name, color and category.
   * For anything that offers a status to pick, use `activeStatuses`.
   */
  statuses: IssueStatusEntry[];
  /** Assignable statuses — `statuses` minus archived ones. */
  activeStatuses: IssueStatusEntry[];
  /** Category for a status key; falls back to the built-in map, else "unstarted". */
  categoryOf: (statusKey: string) => IssueStatusCategory;
  /** Human label for a status key; falls back to the category label, then the raw key. */
  labelOf: (statusKey: string) => string;
  /** Catalog entry for a status key, when the catalog knows it. */
  entryOf: (statusKey: string) => IssueStatusEntry | undefined;
  /**
   * The `#rrggbb` a surface must paint a status with, or null when it keeps
   * its category's semantic token.
   *
   * ALWAYS null for a built-in. The seven built-ins carry a seeded hex in the
   * catalog, but they are not recolorable (the server rejects any edit to a
   * system row) and every surface renders them from the token — `text-success`
   * and friends, which is what makes them follow the theme into dark mode. A
   * caller that reaches for `entryOf(key)?.color` instead paints the raw seed
   * and drifts from the same status two pixels away. (MUL-6440)
   */
  colorOf: (statusKey: string) => string | null;
  /** Custom visual geometry; null keeps the default. Never drives behavior. */
  iconOf: (statusKey: string) => string | null;
  /** ACTIVE statuses belonging to one category, in display order. */
  inCategory: (category: IssueStatusCategory) => IssueStatusEntry[];
  /** True once the catalog has loaded; false while it is still in flight. */
  isLoaded: boolean;
  /**
   * The catalog is still in flight and nothing has resolved yet.
   *
   * A surface that routes on a CUSTOM status key has to hold its loading state
   * while this is true. `isLoaded === false` alone is not enough to act on:
   * the difference between "not here yet" and "the request failed" decides
   * whether the user sees a spinner or a retryable error, and the first cut
   * showed neither — just a silently empty board. (MUL-6243)
   */
  isPending: boolean;
  /**
   * The catalog request failed AND there is no usable snapshot to fall back on.
   *
   * Narrower than "the query errored" on purpose: a BACKGROUND refetch can fail
   * while the last successful catalog is still cached, and blocking a surface
   * then would throw away data that is perfectly serviceable. Only a failure
   * with nothing behind it is worth stopping for. (MUL-6243)
   */
  isError: boolean;
  /** Re-runs the catalog request. Wired to the surface's retry affordance. */
  retry: () => void;
  /**
   * True when the catalog is LOADED and holds at least one custom status.
   *
   * This is the switch for the category-grouped surface contract. Two reasons
   * it has to be both conditions:
   *
   * - Rolling deploy. `group.kind=status_category` is a server contract this
   *   feature introduced, so a client that sends it unconditionally 400s
   *   against any pod that has not been updated yet. A workspace only HAS a
   *   custom status once the creation flag was on, which means the fleet was
   *   already serving this version.
   * - Cold load. Until the catalog lands, `categoryOf` cannot tell a custom key
   *   from an unknown one and falls back to `unstarted`. Routing on that guess
   *   sends a saved `qa` filter to the wrong column and renders an empty board.
   *
   * Retained for callers that need to distinguish whether a workspace has
   * extended its status vocabulary. (MUL-6243)
   */
  hasCustomStatuses: boolean;
}

const BUILT_IN = new Set<string>(BUILT_IN_STATUS_ORDER);
const CATEGORY = new Set<string>(STATUS_ORDER);

const CATEGORY_RANK = new Map<string, number>(STATUS_ORDER.map((c, i) => [c, i]));
const BUILT_IN_RANK = new Map<string, number>(
  BUILT_IN_STATUS_ORDER.map((status, index) => [status, index]),
);

/**
 * The server's catalog ordering, mirrored for client-side re-sorts.
 * Category rank, then intra-category position, then built-in rank/key to break ties —
 * see `ListIssueStatusEntries` in `issue_status.sql`. An optimistic reorder has
 * to re-sort with this or the new positions land in the cache while the list
 * still renders in the old order.
 */
export function compareIssueStatusEntries(a: IssueStatusEntry, b: IssueStatusEntry): number {
  const rank =
    (CATEGORY_RANK.get(normalizeIssueStatusCategory(a.category) ?? "") ?? STATUS_ORDER.length) -
    (CATEGORY_RANK.get(normalizeIssueStatusCategory(b.category) ?? "") ?? STATUS_ORDER.length);
  if (rank !== 0) return rank;
  if (a.position !== b.position) return a.position - b.position;
  if (a.is_system !== b.is_system) return a.is_system ? -1 : 1;
  if (a.is_system && b.is_system) {
    const builtInRank =
      (BUILT_IN_RANK.get(a.key) ?? BUILT_IN_STATUS_ORDER.length) -
      (BUILT_IN_RANK.get(b.key) ?? BUILT_IN_STATUS_ORDER.length);
    if (builtInRank !== 0) return builtInRank;
  }
  return a.key.localeCompare(b.key);
}

export function isIssueStatusCategory(value: string): value is IssueStatusCategory {
  return CATEGORY.has(value);
}

export function isBuiltInIssueStatus(value: string): value is BuiltInIssueStatus {
  return BUILT_IN.has(value);
}

export { normalizeIssueStatusCategory } from "../issues/config/status";

/**
 * The color to paint one catalog entry with — its own hex for a custom status,
 * null for a built-in or an entry this client has not resolved yet.
 *
 * The pure form of {@link IssueStatusCatalog.colorOf}, for callers that already
 * hold the entry (a list they are mapping over) instead of just its key.
 */
export function issueStatusColor(entry: IssueStatusEntry | undefined): string | null {
  if (!entry || entry.is_system === true) return null;
  return entry.color;
}

/**
 * Builds the resolved catalog from a raw entry list. Pure, so the store and
 * other non-React callers can use it with a list they already hold.
 */
export function buildIssueStatusCatalog(
  entries: IssueStatusEntry[] | undefined,
  status: { isPending?: boolean; isError?: boolean; retry?: () => void } = {},
): IssueStatusCatalog {
  const list = entries ?? [];
  const byKey = new Map(list.map((e) => [e.key, e]));

  const categoryOf = (statusKey: string): IssueStatusCategory => {
    const category = byKey.get(statusKey)?.category;
    const normalized = category ? normalizeIssueStatusCategory(category) : null;
    if (normalized) return normalized;
    if (isBuiltInIssueStatus(statusKey)) return BUILT_IN_STATUS_CATEGORY[statusKey];
    // An unknown custom key: render it somewhere sane rather than dropping it.
    return "unstarted";
  };

  return {
    statuses: list,
    activeStatuses: list.filter((e) => !e.archived_at),
    categoryOf,
    entryOf: (statusKey) => byKey.get(statusKey),
    colorOf: (statusKey) => issueStatusColor(byKey.get(statusKey)),
    iconOf: (statusKey) => {
      const entry = byKey.get(statusKey);
      return entry && !entry.is_system ? entry.icon || null : null;
    },
    labelOf: (statusKey) => {
      const entry = byKey.get(statusKey);
      if (entry) return entry.name;
      if (isBuiltInIssueStatus(statusKey)) return BUILT_IN_STATUS_LABEL[statusKey];
      if (isIssueStatusCategory(statusKey)) return STATUS_CONFIG[statusKey].label;
      return statusKey;
    },
    inCategory: (category) =>
      list.filter(
        (e) => normalizeIssueStatusCategory(e.category) === category && !e.archived_at,
      ),
    isLoaded: entries !== undefined,
    // Defaults describe a non-React caller holding a list it already has:
    // resolved when entries are present, still pending when they are not.
    isPending: status.isPending ?? entries === undefined,
    // A failure that still has entries behind it is a stale-data situation, not
    // a blocking one.
    isError: (status.isError ?? false) && entries === undefined,
    retry: status.retry ?? (() => {}),
    hasCustomStatuses:
      entries !== undefined && list.some((e) => e.is_system !== true),
  };
}
