import type { ChatSession } from "./chat";

export type AgentStatus = "idle" | "working" | "blocked" | "error" | "offline";

export type AgentRuntimeMode = "local" | "cloud";

export type AgentVisibility = "workspace" | "private";

// ---------------------------------------------------------------------------
// Agent invocation permissions (MUL-3963)
//
// `permission_mode` + `invocation_targets` are the AUTHORITATIVE gate for who
// may TRIGGER / assign / @mention / chat an agent. The legacy `visibility`
// field REMAINS but is now DERIVED on the backend from these two: a
// `public_to` agent WITH a workspace target maps to `visibility: "workspace"`;
// everything else (private, or public_to scoped only to member/team targets)
// maps to `visibility: "private"`.
//
// Invocation semantics:
//   - owner: always
//   - permission_mode "private": ONLY the owner (workspace admins no longer
//     bypass — the key behavior change vs the old visibility model)
//   - permission_mode "public_to" + workspace target: any workspace member
//   - permission_mode "public_to" + member target: only the matching user
//   - team target: reserved, INERT in v1 (never grants)
// ---------------------------------------------------------------------------

export type AgentPermissionMode = "private" | "public_to";

/**
 * A single invocation grant on an agent. `target_id` is `null` for the
 * workspace target (the grant covers every workspace member); it carries the
 * member / team id for the scoped grants.
 */
export interface AgentInvocationTarget {
  target_type: "workspace" | "member" | "team";
  target_id: string | null;
}

/**
 * Wire shape for invocation targets on CREATE / UPDATE requests. For a
 * workspace target the client may omit `target_id` (the backend fills the
 * workspace id); member / team targets REQUIRE it.
 */
export interface AgentInvocationTargetInput {
  target_type: "workspace" | "member" | "team";
  target_id?: string;
}

// Runtime visibility is a separate axis from agent visibility — different
// vocabulary because it gates a different action. "private" (default) means
// only the runtime owner can bind agents to it — workspace admins included,
// and only the owner may flip the flag (MUL-6126); "public" opens binding to
// any workspace member. Older backends that haven't shipped MUL-2062 omit the
// field; the consumer must default to "private" so the strictest behavior is
// the fallback.
export type RuntimeVisibility = "private" | "public";

export interface RuntimeDevice {
  id: string;
  workspace_id: string;
  daemon_id: string | null;
  name: string;
  /**
   * Optional user-set display name override (MUL-4217). Overrides `name` for
   * display; the daemon never writes it, so it survives heartbeats. Older
   * backends omit the field — consumers must treat missing / empty as "use
   * name" (see runtimeDisplayName).
   */
  custom_name?: string | null;
  runtime_mode: AgentRuntimeMode;
  provider: string;
  launch_header: string;
  status: "online" | "offline";
  device_info: string;
  metadata: Record<string, unknown>;
  owner_id: string | null;
  /** Defaults to "private" when the backend predates the visibility flag. */
  visibility: RuntimeVisibility;
  /**
   * The custom runtime profile this registered runtime was launched from,
   * or `null` for a built-in protocol family. The UI uses this to stamp a
   * "Built-in" vs "Custom" badge on the runtime row. Older backends that
   * predate the custom-runtime feature omit the field; consumers must treat
   * a missing value as `null` (built-in).
   */
  profile_id?: string | null;
  last_seen_at: string | null;
  created_at: string;
  updated_at: string;
}

export type AgentRuntime = RuntimeDevice;

// ---------------------------------------------------------------------------
// Custom runtime profiles (MUL-3284)
//
// A RuntimeProfile is a workspace-level *definition* of a custom runtime
// backend — distinct from a RuntimeDevice, which is a daemon-registered
// *instance*. An admin authors a profile (display name + base protocol
// family + the CLI command to launch), and daemons can then register
// runtimes against it; those instances carry `profile_id` pointing back here.
// ---------------------------------------------------------------------------

// The fixed allow-list of base protocol families a custom runtime can wrap.
// These are the only backends the create flow may select; the server rejects
// anything else with 400. Kept as a const tuple so the union type is derived
// from the single source of truth.
export const RUNTIME_PROFILE_PROTOCOL_FAMILIES = [
  "claude",
  "codebuddy",
  "codex",
  "copilot",
  "opencode",
  "codearts",
  "deveco",
  "openclaw",
  "hermes",
  "pi",
  "cursor",
  "kimi",
  "reasonix",
  "dsh",
  "dim",
  "kiro",
  "antigravity",
  "qoder",
  "qoderclicn",
  "traecli",
  "grok",
  "qwen",
  "qwenpaw",
  "mcode",
  "zeroclaw",
] as const;

export type RuntimeProtocolFamily =
  (typeof RUNTIME_PROFILE_PROTOCOL_FAMILIES)[number];

// Profile visibility mirrors RuntimeVisibility's vocabulary but uses the
// workspace/private axis the server documents for profiles.
export type RuntimeProfileVisibility = "workspace" | "private";

export interface RuntimeProfile {
  id: string;
  workspace_id: string;
  display_name: string;
  protocol_family: RuntimeProtocolFamily;
  command_name: string;
  description: string | null;
  fixed_args: string[];
  visibility: RuntimeProfileVisibility;
  created_by: string | null;
  enabled: boolean;
  created_at: string;
  updated_at: string;
}

// POST body. `protocol_family` is required and immutable after creation.
// Optional fields are omitted entirely when unset (never sent as null/empty)
// so the server applies its own defaults.
export interface CreateRuntimeProfileRequest {
  display_name: string;
  protocol_family: RuntimeProtocolFamily;
  command_name: string;
  description?: string;
  fixed_args?: string[];
  visibility?: RuntimeProfileVisibility;
  enabled?: boolean;
}

// PATCH body — every field optional; `protocol_family` is intentionally
// absent because it is immutable.
export interface UpdateRuntimeProfileRequest {
  display_name?: string;
  command_name?: string;
  description?: string | null;
  fixed_args?: string[];
  visibility?: RuntimeProfileVisibility;
  enabled?: boolean;
}

// Coarse classifier set by the backend when a task transitions to "failed".
// Mirrors the migration-055 enum in agent_task_queue.failure_reason. Used by
// the agent presence derivation and the UI failure-message lookup.
export type TaskFailureReason =
  | "agent_error"
  | "timeout"
  | "codex_semantic_inactivity"
  | "runtime_offline"
  | "runtime_reconnect_timeout"
  | "runtime_recovery"
  | "manual";

// One daily bucket for the Agents-list ACTIVITY sparkline. The back-end
// only returns days that had at least one completion; the front-end fills
// in missing days with zero when rendering the 7-bucket series. The series
// is anchored on completed_at (a task in flight contributes nothing).
export interface AgentActivityBucket {
  agent_id: string;
  // ISO timestamp at midnight UTC of the day.
  bucket_at: string;
  task_count: number;
  failed_count: number;
}

// 30-day total run count per agent, drives the Agents-list RUNS column.
export interface AgentRunCount {
  agent_id: string;
  run_count: number;
}

// Privacy-safe display summary returned by GET /api/working-agents. The
// endpoint is workspace-scoped and includes each user-authored agent with at
// least one running task exactly once.
export interface WorkspaceWorkingAgent {
  id: string;
  name: string;
  avatar_url: string | null;
  running_task_count: number;
  /** Distinct issues referenced by this agent's currently running tasks after
   *  applying the endpoint's type/scope/relation filters. */
  issue_ids: string[];
}

export type WorkspaceWorkingAgentType = "issue" | "autopilot" | "chat";

export type WorkspaceWorkingAgentMineRelation =
  | "assigned"
  | "created"
  | "involved"
  | "any";

/**
 * A departed-member-safe user ref resolved from the global user table. `name` /
 * `email` / `avatar_url` are absent until the server hydrates them (present on
 * user-facing task surfaces). Render defensively — fall back to a generic label
 * when only `id` is available. See MUL-4302 §9.
 */
export interface AttributionUser {
  id: string;
  name?: string;
  email?: string;
  avatar_url?: string;
}

/** The kind-tagged handle to a run's direct cause (comment, autopilot run, ...). */
export interface TaskEvidence {
  kind: string;
  ref_id: string;
}

/**
 * The resolved accountable-human provenance of an agent run (MUL-4302 §9). Free-text
 * `source` (server may add new levels), so switch on it with a default branch.
 */
export interface TaskAttribution {
  /**
   * Waterfall level that resolved the accountable human:
   * `direct_human` | `delegation` | `comment_source` | `rule_owner` |
   * `owner_fallback` | `backfill` | `unattributed`. Never blank.
   */
  source: string;
  /** False for degraded sources (owner_fallback / backfill / unattributed). */
  precise: boolean;
  /** The accountable human ("on behalf of"). Absent when unattributed. */
  initiator?: AttributionUser;
  /** The authorization human; absent for autopilot runs (rule_owner / owner_fallback). */
  originator?: AttributionUser;
  /** The direct cause of the run, for a jump-to-evidence affordance. */
  evidence?: TaskEvidence;
  rule_version_id?: string;
  delegated_from_task_id?: string;
  retry_of_task_id?: string;
  rerun_of_task_id?: string;
}

/** Point-in-time identity of the actor that cancelled a run. */
export interface TaskCancellationActor {
  /** Open wire value; current servers emit member, agent, or system. */
  type: string;
  id?: string;
  name?: string;
}

export interface AgentTask {
  id: string;
  agent_id: string;
  runtime_id: string;
  // Empty string ("") when the task has no linked issue — either chat- or
  // autopilot-spawned. Check chat_session_id / autopilot_run_id to tell
  // which source produced it.
  issue_id: string;
  // `waiting_local_directory` is the daemon-emitted hold state for the
  // local_directory flow: a task that has been dispatched but is parked
  // because another task currently owns the same on-disk path lock.
  // Treated as an active (non-terminal) state alongside queued/dispatched/
  // running by every consumer that buckets tasks into "active vs done".
  status:
    | "queued"
    | "dispatched"
    | "waiting_local_directory"
    | "running"
    | "completed"
    | "failed"
    | "cancelled";
  priority: number;
  dispatched_at: string | null;
  started_at: string | null;
  completed_at: string | null;
  result: unknown;
  error: string | null;
  // Empty string when the task is not in a failed state (the backend uses
  // `omitempty`, so the field may also be missing on non-failed tasks).
  // Open string on the wire, not a closed enum: the backend's classifier
  // taxonomy has grown far past TaskFailureReason (21+ refined
  // `agent_error.*` reasons since MUL-1949, `local_directory_error`, …) and
  // keeps growing — an installed client will meet reasons its build
  // predates. TaskFailureReason stays in the union for autocomplete on the
  // coarse values; `string & {}` admits the rest without collapsing the
  // hints.
  failure_reason?: TaskFailureReason | (string & {}) | "";
  /** The input comment was edited or deleted, invalidating this run. */
  cancelled_by_comment_change?: boolean;
  /** Present on cancellations recorded by a backend with actor provenance. */
  cancelled_by?: TaskCancellationActor;
  created_at: string;
  /** Non-empty when the task was spawned from a chat session. */
  chat_session_id?: string;
  /** Non-empty when the task was spawned by an autopilot run. */
  autopilot_run_id?: string;
  /** Set when this task was created as an auto-retry of a parent task. */
  parent_task_id?: string;
  /** 1-based attempt counter; >1 means this is a retry. */
  attempt?: number;
  /** Set when an issue comment triggered this task (@mention or assignee comment). */
  trigger_comment_id?: string;
  /**
   * Earlier comment IDs folded into this run before it was claimed. This does
   * not include `trigger_comment_id`, which remains the run's newest trigger.
   * Their unique union is the queued coverage plan; claimed-task consumers
   * should prefer `delivered_comment_ids` when that receipt is present. Omitted
   * by older backends and for runs that were not merged.
   */
  coalesced_comment_ids?: string[];
  /**
   * Comment IDs actually embedded in the task's latest claim response. Once a
   * task has left queued state this is the authoritative coverage receipt.
   * Omitted by older backends, where consumers may fall back to the planned
   * trigger/coalesced union; an explicitly empty array is still authoritative.
   */
  delivered_comment_ids?: string[];
  /**
   * Canonical short description of what triggered this task — snapshot
   * taken at creation time. For comment-triggered tasks it's the
   * comment text (truncated to ~200 chars); for autopilot it's the
   * autopilot title; NULL for direct assignments and chat tasks.
   * Persists even if the source comment / autopilot is later edited
   * or deleted.
   */
  trigger_summary?: string;
  /**
   * Server-computed source discriminator used by task surfaces. Quick-create
   * remains quick_create after its result issue is linked, so consumers can
   * distinguish creation work from later direct runs on that issue.
   */
  kind?: "comment" | "autopilot" | "chat" | "quick_create" | "direct";
  /**
   * Local working directory pinned for this task by the daemon. Empty until
   * the daemon reports a work_dir (typically once execution starts). This is
   * the canonical absolute path the agent runs in; UI surfaces should prefer
   * `relative_work_dir` to avoid leaking the user's home directory.
   */
  work_dir?: string;
  /**
   * Privacy-safe display form of `work_dir`, derived on the server. For
   * standard tasks the daemon's workspaces root has been stripped off
   * (`<wsUUID>/<taskShort>/workdir`); for local_directory tasks where the
   * path lives outside that layout, the server strips recognised home
   * prefixes (`/Users/<name>/`, `/home/<name>/`, `<drive>:/Users/<name>/`)
   * and otherwise falls back to the basename so neither the home directory
   * nor the username leak into the UI. Older backends omit the field —
   * render it conditionally and never render `work_dir` raw (not even in
   * a tooltip / `title` / `aria-label`, since the goal is that screen
   * shares and screenshots also stay safe).
   */
  relative_work_dir?: string;
  /**
   * Durable directory that replaces `work_dir` after the daemon confirms a
   * disposable local worktree was finalized and removed. Terminal tasks may
   * use this for explicit clipboard actions; its absence means `work_dir`
   * remains authoritative (including preserved-worktree failures and older
   * daemon/server combinations). This is a point-in-time delivery snapshot;
   * later resource renames or detachments do not rewrite historical tasks.
   */
  durable_work_dir?: string;
  /**
   * Privacy-safe display form of `durable_work_dir`. Never render the absolute
   * durable path directly; older backends omit both fields.
   */
  relative_durable_work_dir?: string;
  /**
   * Git branch this run delivered its work on. Set only by worktree-mode
   * local_directory tasks, where the agent never touches the user's working
   * copy — the branch is the only pointer to what it produced.
   *
   * Present on failed runs too: worktree mode commits whatever the agent left
   * before tearing the worktree down, so a run that died partway still has
   * something worth finding. Unlike `work_dir` this is safe to render
   * verbatim; it is a ref inside the user's own repo, not a filesystem path.
   * Older backends omit it — render conditionally.
   */
  branch_name?: string;
  /**
   * Resolved accountable-human provenance of this run (MUL-4302 §9): who it ran
   * "on behalf of", how that was resolved, and the evidence/lineage. Present on
   * user-facing task surfaces; older backends omit it — render conditionally.
   */
  attribution?: TaskAttribution;
  /**
   * This run's own token consumption, one entry per (provider, model) it used.
   * Present on issue execution logs and explicit agent-history accounting
   * requests; normal UI history and daemon claims omit it.
   *
   * `undefined` (old backend, or a surface that doesn't hydrate it) and `[]`
   * (backend hydrated, this run has no recorded usage) both mean "no number to
   * show" and must render as an em dash, never as 0 — a run that predates usage
   * reporting was not free, we just don't know what it cost.
   */
  usage?: TaskUsage[];
}

/**
 * One (provider, model) slice of a single run's token usage.
 *
 * Field names deliberately match {@link RuntimeUsage} so the same
 * `estimateCost` / `estimateCostBreakdown` / `estimateCacheSavings` helpers in
 * `packages/views/runtimes/utils.ts` price a run and a runtime-day identically
 * — there is exactly one cost formula in the product.
 *
 * `cost_usd_ticks` is the provider's own price for this slice (1e-10 USD),
 * absent when it reported none; those tokens get estimated from the rate table
 * instead. Unlike the aggregate rows there is no `uncosted_*` split here: a
 * `task_usage` row is priced or it isn't, so "uncosted" is just "all of them
 * when cost_usd_ticks is absent", which is what the estimator already assumes.
 */
export interface TaskUsage {
  provider?: string;
  model: string;
  input_tokens: number;
  output_tokens: number;
  cache_read_tokens: number;
  cache_write_tokens: number;
  cost_usd_ticks?: number;
}

/**
 * Response of the Mika bootstrap endpoint: the workspace's Mika plus the
 * caller's conversation with it, resolved together server-side so two clients
 * cannot each open their own onboarding session.
 */
export interface MikaBootstrapResponse extends Agent {
  /** Absent only when the server could not resolve the session; retry the
   *  same call rather than creating one client-side. */
  onboarding_session?: ChatSession;
}

export interface Agent {
  id: string;
  workspace_id: string;
  /**
   * Empty string when the agent is unbound: it kept its configuration, chats and
   * task history when its runtime was deleted, and needs a new runtime before it
   * can run again (MUL-5559). Use `isAgentRuntimeBound` so additive and legacy
   * signals stay compatible, and do not confuse it with a bound-but-offline
   * runtime — that one just needs the machine back.
   */
  runtime_id: string;
  /** False exactly when the agent has no runtime. Older backends omit it. */
  runtime_bound?: boolean;
  /** Privacy-safe coarse liveness for a runtime hidden from the runtime list. */
  runtime_availability?: "online" | "unstable" | "offline";
  name: string;
  description: string;
  /** What this agent's owner wrote. For a system agent this holds only the
   *  workspace's own notes — the product half is `system_instructions`. */
  instructions: string;
  /** Up to three agent-authored first-turn suggestions. Older servers omit it. */
  conversation_starters?: AgentConversationStarter[];
  /** Set for product-defined agents (e.g. "mika"). Absent for user- and
   *  template-created agents. Identity for "maintained by Multica" checks —
   *  never the display name, which owners may change. */
  system_key?: string;
  /** Read-only product half of a system agent's prompt, served from the
   *  backend binary. Absent for ordinary agents. */
  system_instructions?: string;
  avatar_url: string | null;
  runtime_mode: AgentRuntimeMode;
  runtime_config: Record<string, unknown>;
  custom_args: string[];
  /**
   * Coarse metadata signalling whether the agent has any custom env
   * vars configured, without exposing the keys or values. Reads of
   * the real map go through the dedicated `GET /api/agents/{id}/env`
   * endpoint (agent owner or workspace owner/admin, audited). MUL-2600.
   *
   * Optional in the type so older backends (pre-MUL-2600) that omit
   * the field don't crash the renderer; downstream code should treat
   * `undefined` as "unknown — assume no env" rather than "definitely
   * has env".
   */
  has_custom_env?: boolean;
  /**
   * Number of keys in the agent's custom_env map. Always present
   * alongside `has_custom_env`. Treat `undefined` as zero. MUL-2600.
   */
  custom_env_key_count?: number;
  /**
   * MCP server configuration forwarded to runtimes that consume
   * `agent.mcp_config` (see providerSupportsMcpConfig). Each backend
   * materialises it in the runtime-native place: Claude flags, Codex
   * config.toml, ACP session params, OpenCode env config, OpenClaw
   * wrapper config, etc. `null` (or the field omitted on legacy backends)
   * means no managed config; the daemon falls back to the CLI's own
   * default. MUL-2764.
   *
   * When the caller can't see secrets (an agent actor, or a non-owner
   * non-admin), the server replaces the value with `null` and sets
   * `mcp_config_redacted` to true so the UI can render a "configured
   * but hidden" state without exposing potentially sensitive fields.
   */
  mcp_config?: unknown | null;
  /**
   * True when the server stripped `mcp_config` from this response
   * because the caller lacks permission to see secrets. The UI uses
   * this to distinguish "no config" (`mcp_config === null &&
   * !mcp_config_redacted`) from "config exists but you can't see it".
   * Older backends omit this field; treat `undefined` as false.
   */
  mcp_config_redacted?: boolean;
  /**
   * The subset of Composio toolkit slugs this agent is allowed to mount as
   * MCP servers at task dispatch — but only when the run originator is the
   * agent owner (MUL-3869 / MUL-3721). `null`/`[]`/omitted all mean "no
   * overlay regardless of who triggers". Owner-only data: the server hands
   * it through verbatim to the owner and redacts it to `undefined` +
   * `composio_toolkit_allowlist_redacted=true` for everyone else (same
   * contract as `mcp_config`). Treat `undefined` as "unknown — assume none".
   */
  composio_toolkit_allowlist?: string[];
  /**
   * True when the server stripped `composio_toolkit_allowlist` from this
   * response because the caller is not the agent owner. The MCP tab is
   * creator-only so a redacted value should never reach the editor, but the
   * UI renders a "hidden" fallback defensively. Older backends omit this
   * field; treat `undefined` as false.
   */
  composio_toolkit_allowlist_redacted?: boolean;
  visibility: AgentVisibility;
  /**
   * Authoritative invocation permission mode (MUL-3963). The `visibility`
   * field above is DERIVED from this on the backend. The current backend
   * always returns this field.
   */
  permission_mode: AgentPermissionMode;
  /**
   * Invocation grants backing `permission_mode === "public_to"` (empty for a
   * private agent). See `AgentInvocationTarget`.
   */
  invocation_targets: AgentInvocationTarget[];
  status: AgentStatus;
  max_concurrent_tasks: number;
  model: string;
  /**
   * Runtime-native reasoning/effort token (e.g. Claude's
   * `low|medium|high|xhigh|max`, Codex's
   * `none|minimal|low|medium|high|xhigh|max|ultra`). Empty string means "no
   * override": the backend omits the effort flag and the upstream CLI
   * config / built-in default decides at run time. The picker is
   * per-runtime per-model — the API never normalises across providers.
   * Older backends omit this field entirely; treat undefined as ""
   * (MUL-2339).
   */
  thinking_level?: string;
  /**
   * Runtime-native Codex service tier (for example `priority`, displayed as
   * Fast). Empty/undefined means no override: local Codex configuration and
   * account defaults remain authoritative.
   */
  service_tier?: string;
  owner_id: string | null;
  skills: AgentSkillSummary[];
  /** Runtime-local skills this agent must not inherit. Older servers omit it. */
  disabled_runtime_skills?: DisabledRuntimeSkill[];
  created_at: string;
  updated_at: string;
  archived_at: string | null;
  archived_by: string | null;
}

export interface AgentConversationStarter {
  /** Short chip label shown in the empty state. */
  label: string;
  /** Full editable text copied into the composer when selected. */
  prompt: string;
}

export interface DisabledRuntimeSkill {
  runtime_id: string;
  provider: string;
  root: "provider" | "universal" | "plugin";
  key: string;
  name?: string;
  plugin?: string;
}

export interface SetAgentRuntimeSkillEnabledRequest {
  runtime_id: string;
  root: "provider" | "universal" | "plugin";
  key: string;
  name: string;
  plugin?: string;
  enabled: boolean;
}

/**
 * Minimal skill shape embedded in an Agent payload (`GET /api/agents`,
 * `GET /api/agents/:id`). Only id/name/description are populated — the
 * agent list batch query joins exactly those three columns. For full skill
 * info, use `GET /api/agents/:id/skills` (returns `SkillSummary[]`) or
 * `GET /api/skills/:id` (returns the full `Skill`).
 */
export interface AgentSkillSummary {
  id: string;
  name: string;
  description: string;
	/** Older servers omit this field; consumers must treat that as enabled. */
	enabled?: boolean;
}

export interface CreateAgentRequest {
  name: string;
  description?: string;
  instructions?: string;
  conversation_starters?: AgentConversationStarter[];
  avatar_url?: string;
  runtime_id: string;
  runtime_config?: Record<string, unknown>;
  custom_env?: Record<string, string>;
  custom_args?: string[];
  visibility?: AgentVisibility;
  /**
   * Invocation permission mode (MUL-3963). When present it is authoritative;
   * when absent the backend maps the legacy `visibility` field
   * (private -> private, workspace -> public_to + workspace target). On
   * UPDATE, permission changes are OWNER-ONLY (the backend silently ignores
   * these fields from non-owner admins).
   */
  permission_mode?: AgentPermissionMode;
  /** Invocation grants — see `AgentInvocationTargetInput`. */
  invocation_targets?: AgentInvocationTargetInput[];
  max_concurrent_tasks?: number;
  model?: string;
  /** Optional runtime-native reasoning/effort token. See `Agent.thinking_level`. */
  thinking_level?: string;
  /** Optional Codex service-tier catalog ID. See `Agent.service_tier`. */
  service_tier?: string;
  /** Optional creation-source attribution. Surfaced as the `template`
   *  property on the `agent_created` PostHog event. */
  template?: string;
  /** Workspace skill IDs attached atomically with the agent row. */
  skill_ids?: string[];
}

export interface AgentBuilderSession {
  session_id: string;
  builder_agent_id: string;
  runtime_id: string;
}

/** Who may invoke the agent being created, as the creation form models it. */
export type AgentPermissionScope = "private" | "workspace" | "members";

/**
 * The wire form of an in-progress agent configuration.
 *
 * Differs from the editable draft in two deliberate ways: `Set` becomes an
 * array (JSON has no sets), and there is no runtime — which runtime a
 * conversation executes on is owned by its carrier agent server-side, and a
 * copy here could only go stale. `applied_message_id` travels along because it
 * is what stops a restore from re-applying the last reply's `<agent_draft>`
 * over edits the user made after it.
 */
export interface StoredAgentDraft {
  name: string;
  description: string;
  instructions: string;
  conversation_starters: AgentConversationStarter[];
  avatar_url: string | null;
  model: string;
  thinking_level: string;
  service_tier: string;
  skill_ids: string[];
  permission_scope: AgentPermissionScope;
  member_ids: string[];
  team_ids: string[];
  applied_message_id: string | null;
}

/** One unfinished agent-creation conversation, as listed by the studio. */
export interface AgentBuilderSessionSummary {
  session_id: string;
  title: string;
  /** The carrier's runtime — where this conversation actually executes. The
   *  picker seeds from it so it can never disagree with what answers the next
   *  message (MUL-5163). */
  runtime_id: string;
  created_at: string;
  updated_at: string;
  /** Still in the builder wire format; decode with the builder protocol helpers
   *  before showing it to a human. */
  last_message_content: string;
  last_message_role: string;
  last_message_at: string;
  /** The stored configuration, or null when the conversation has never been
   *  hand-edited — the client then replays the last `<agent_draft>` block. */
  draft?: StoredAgentDraft | null;
}

/** Result of rebinding a live builder conversation to another runtime.
 *  `runtime_id` is the runtime the server actually bound — the caller must
 *  wait for it before showing the new runtime as selected. */
export interface AgentBuilderRuntimeSwitch {
  runtime_id: string;
}

export interface UpdateAgentRequest {
  name?: string;
  description?: string;
  instructions?: string;
  conversation_starters?: AgentConversationStarter[];
  avatar_url?: string;
  runtime_id?: string;
  runtime_config?: Record<string, unknown>;
  /**
   * NOTE: `custom_env` is intentionally NOT updatable through this
   * request shape. Env edits flow through `client.updateAgentEnv` /
   * `PUT /api/agents/{id}/env` — that path admits the agent owner or a
   * workspace owner/admin, denies agent actors, and writes a
   * persistent audit row. The
   * server REJECTS any `PUT /api/agents/{id}` body that includes
   * `custom_env` with a 400; do not put the field in this payload.
   * MUL-2600.
   */
  custom_args?: string[];
  /**
   * MCP server configuration. Tri-state semantics (MUL-2764):
   *   - field omitted → no change
   *   - `null` → clear the column; the daemon falls back to the CLI's
   *     built-in default at launch
   *   - object → replace the stored JSON verbatim; runtime backends
   *     validate / translate it according to their own MCP integration
   */
  mcp_config?: unknown | null;
  /**
   * Composio toolkit allowlist. Tri-state semantics, mirroring the backend
   * gate (MUL-3869):
   *   - field omitted → no change
   *   - `null` → clear the column (no MCP overlay for anyone)
   *   - string[] → wholesale replace; the server lowercases / trims / dedupes
   *     the slugs before persisting
   * Writes are silently dropped server-side unless the caller is the agent
   * owner, so the UI only ever exposes this field through the creator-only
   * MCP tab.
   */
  composio_toolkit_allowlist?: string[] | null;
  visibility?: AgentVisibility;
  /**
   * Invocation permission mode (MUL-3963). When present it is authoritative;
   * when absent the backend maps the legacy `visibility` field
   * (private -> private, workspace -> public_to + workspace target). On
   * UPDATE, permission changes are OWNER-ONLY (the backend silently ignores
   * these fields from non-owner admins).
   */
  permission_mode?: AgentPermissionMode;
  /** Invocation grants — see `AgentInvocationTargetInput`. */
  invocation_targets?: AgentInvocationTargetInput[];
  status?: AgentStatus;
  max_concurrent_tasks?: number;
  model?: string;
  /**
   * Runtime-native reasoning/effort token. Tri-state semantics (MUL-2339):
   *   - field omitted → no change
   *   - "" → clear the override; backend omits the effort flag and the
   *     local CLI config / built-in default decides what the model runs at
   *   - non-empty → set; validated server-side against the target
   *     runtime's provider enum, rejected with 400 if not recognised
   */
  thinking_level?: string;
  /**
   * Codex service-tier override. Omitted preserves the saved value, `""`
   * clears it, and a non-empty value stores a runtime-catalog ID.
   */
  service_tier?: string;
}

/**
 * Wire shape for the dedicated env-management endpoints
 * (`GET /api/agents/{id}/env` and `PUT /api/agents/{id}/env`). Kept
 * deliberately separate from `Agent` so generic agent reads cannot
 * accidentally surface env values. MUL-2600.
 */
export interface AgentEnvResponse {
  agent_id: string;
  custom_env: Record<string, string>;
}

/**
 * Body for `PUT /api/agents/{id}/env`. Values equal to `"****"` are
 * treated by the server as "preserve the existing value for this key"
 * — a defence-in-depth guard so a UI that round-trips a masked map
 * cannot accidentally clobber real secrets. Submit only the keys
 * touched in the form; omitted keys are removed by the server.
 */
export interface UpdateAgentEnvRequest {
  custom_env: Record<string, string>;
}

// Skills

/**
 * Lightweight skill shape returned by list endpoints (`GET /api/skills`,
 * `GET /api/agents/:id/skills`). The full SKILL.md `content` is intentionally
 * omitted — bodies routinely run 50–200KB each and shipping them in list
 * payloads tripped CLI timeouts on high-latency links (GH
 * multica-ai/multica#2174). Use `Skill` from a detail endpoint when you need
 * the body. For skills embedded in an `Agent` payload see `AgentSkillSummary`.
 */
export interface SkillSummary {
  id: string;
  workspace_id: string;
  name: string;
  description: string;
  config: Record<string, unknown>;
  created_by: string | null;
  created_at: string;
  updated_at: string;
	/** Present only when returned from an agent-scoped assignment endpoint. */
	enabled?: boolean;
}

export interface Skill extends SkillSummary {
  content: string;
  files: SkillFile[];
}

export interface SkillFile {
  id: string;
  skill_id: string;
  path: string;
  content: string;
  created_at: string;
  updated_at: string;
}

export interface CreateSkillRequest {
  name: string;
  description?: string;
  content?: string;
  config?: Record<string, unknown>;
  files?: { path: string; content: string }[];
}

/** Structured body of POST /api/skills/import when uploading an archive. */
export interface SkillImportResult {
  status: "created" | "updated" | "conflict" | "skipped" | "failed";
  reason?: string;
  skill?: Skill;
  existing_skill?: {
    id: string;
    name: string;
    created_by?: string;
    can_overwrite?: boolean;
  };
}

export interface UpdateSkillRequest {
  name?: string;
  description?: string;
  content?: string;
  config?: Record<string, unknown>;
  files?: { path: string; content: string }[];
}

export interface SetAgentSkillsRequest {
  skill_ids: string[];
}

export interface IssueUsageSummary {
  total_input_tokens: number;
  total_output_tokens: number;
  total_cache_read_tokens: number;
  total_cache_write_tokens: number;
  // Optional unlike the usage-row types: `getIssueUsage` returns this shape
  // unvalidated (no zod schema), so nothing guarantees the field is present
  // when the backend is older than the cost split.
  cost_usd_ticks?: number;
  uncosted_input_tokens?: number;
  uncosted_output_tokens?: number;
  uncosted_cache_read_tokens?: number;
  uncosted_cache_write_tokens?: number;
  // Coverage fields are optional for compatibility with older backends.
  // task_count remains the legacy count of runs represented by usage rows.
  terminal_task_count?: number;
  metered_task_count?: number;
  unreported_task_count?: number;
  task_count: number;
}

// `cost_usd_ticks` + `uncosted_*`: the cost split every usage row carries.
// All five are optional: a backend older than the split sends none of them,
// and `undefined` has to stay distinguishable from a real 0 (see below).
// The provider priced the rows behind `cost_usd_ticks` itself (1e-10 USD);
// `uncosted_*` are the tokens it did not price, and are the only ones that
// should go through the client's rate table. The `uncosted_*` fields are
// optional because a backend older than the split omits them — `undefined`
// there means "estimate from the full token counts", which is not the same as
// a real 0 ("nothing left to estimate"). See estimateCost in
// packages/views/runtimes/utils.ts.
export interface RuntimeUsage {
  runtime_id: string;
  date: string;
  provider: string;
  model: string;
  input_tokens: number;
  output_tokens: number;
  cache_read_tokens: number;
  cache_write_tokens: number;
  cost_usd_ticks?: number;
  uncosted_input_tokens?: number;
  uncosted_output_tokens?: number;
  uncosted_cache_read_tokens?: number;
  uncosted_cache_write_tokens?: number;
}

export interface RuntimeHourlyActivity {
  hour: number;
  count: number;
}

// One (agent, provider, model) row of the "Cost by agent" tab on the runtime
// detail page. provider + model stay on the wire because cost is computed
// client-side from a per-model pricing table (provider disambiguates bare
// model ids that collide across providers) — the client groups these rows by
// agent_id and sums cost per agent across models.
export interface RuntimeUsageByAgent {
  agent_id: string;
  provider: string;
  model: string;
  input_tokens: number;
  output_tokens: number;
  cache_read_tokens: number;
  cache_write_tokens: number;
  cost_usd_ticks?: number;
  uncosted_input_tokens?: number;
  uncosted_output_tokens?: number;
  uncosted_cache_read_tokens?: number;
  uncosted_cache_write_tokens?: number;
  task_count: number;
}

// One (hour, model) row for the "By hour" tab; hour ∈ 0..23. Hours with
// zero activity are omitted by the server; the client fills the gap to
// render a continuous axis. Model preserved for client-side cost math.
export interface RuntimeUsageByHour {
  hour: number;
  model: string;
  input_tokens: number;
  output_tokens: number;
  cache_read_tokens: number;
  cache_write_tokens: number;
  cost_usd_ticks?: number;
  uncosted_input_tokens?: number;
  uncosted_output_tokens?: number;
  uncosted_cache_read_tokens?: number;
  uncosted_cache_write_tokens?: number;
  task_count: number;
}

// One (date, provider, model) bucket of token usage for the workspace
// dashboard. Workspace-scoped (no runtime_id) and optionally narrowed to a
// single project on the server side. `provider` is kept on the wire so the
// client can disambiguate bare model ids that collide across providers
// (e.g. Cursor's `auto` vs another provider's `auto`) when pricing. Cost
// stays client-side via the model pricing table.
export interface DashboardUsageDaily {
  date: string;
  provider: string;
  model: string;
  input_tokens: number;
  output_tokens: number;
  cache_read_tokens: number;
  cache_write_tokens: number;
  cost_usd_ticks?: number;
  uncosted_input_tokens?: number;
  uncosted_output_tokens?: number;
  uncosted_cache_read_tokens?: number;
  uncosted_cache_write_tokens?: number;
  task_count: number;
}

// Per-(agent, model) token totals for the workspace dashboard. Identical
// wire shape to RuntimeUsageByAgent — the client folds by agent_id and
// sums cost.
export interface DashboardUsageByAgent {
  agent_id: string;
  provider: string;
  model: string;
  input_tokens: number;
  output_tokens: number;
  cache_read_tokens: number;
  cache_write_tokens: number;
  cost_usd_ticks?: number;
  uncosted_input_tokens?: number;
  uncosted_output_tokens?: number;
  uncosted_cache_read_tokens?: number;
  uncosted_cache_write_tokens?: number;
  task_count: number;
}

// Per-agent total terminal-task run-time + counts. Powers the workspace
// dashboard's "time by agent" list. failed_count is a subset of
// task_count (failed tasks still contribute to total_seconds because
// they consumed runtime to fail).
export interface DashboardAgentRunTime {
  agent_id: string;
  total_seconds: number;
  task_count: number;
  // Optional for compatibility with backends predating usage-coverage
  // reporting. Consumers can still identify the fully-unreported case when
  // this is absent by checking whether the agent has any usage rows.
  metered_task_count?: number;
  failed_count: number;
  // Runs the user stopped mid-flight. Disjoint from `failed_count`, and
  // both are subsets of `task_count` — the succeeded count is the
  // remainder. A stopped run still occupied an agent and still spent
  // tokens, so its seconds belong in `total_seconds`.
  cancelled_count: number;
}

// One (date) bucket of terminal-task run-time + counts for the workspace
// dashboard. Powers the Time and Tasks metrics on the daily-trend toggle
// — same toggle as Tokens / Cost, anchored on completed_at so day buckets
// line up with the per-agent run-time card.
export interface DashboardRunTimeDaily {
  date: string;
  total_seconds: number;
  task_count: number;
  failed_count: number;
  // See DashboardAgentRunTime.cancelled_count.
  cancelled_count: number;
}

// One (date, failure_reason) bucket of terminal-task counts for the workspace
// dashboard's Errors metric.
//
// `failure_reason` carries the backend's canonical failure taxonomy (the 21
// `taskfailure.Reason` values, plus `"unclassified"` for failed rows with an
// empty column) — EXCEPT for the empty string, which is the *succeeded*
// bucket. Shipping successes in the same series is deliberate: the error rate
// then has a denominator built on exactly the same filters as its numerator.
// `DashboardRunTimeDaily.task_count` is NOT a safe denominator here, because
// it only counts tasks that actually started and a queue-expired task never
// does.
export interface DashboardFailureDaily {
  date: string;
  failure_reason: string;
  task_count: number;
}

// Per-(agent, failure_reason) terminal-task counts. Same succeeded-bucket
// convention as DashboardFailureDaily, so the client can rank agents by
// failure rate rather than by raw failure count.
export interface DashboardFailureByAgent {
  agent_id: string;
  failure_reason: string;
  task_count: number;
}

export type RuntimeUpdateStatus =
  | "pending"
  | "running"
  | "completed"
  | "failed"
  | "timeout";

export interface RuntimeUpdate {
  id: string;
  runtime_id: string;
  status: RuntimeUpdateStatus;
  target_version: string;
  output?: string;
  error?: string;
  created_at: string;
  updated_at: string;
}

export interface RuntimeModel {
  id: string;
  label: string;
  provider?: string;
  default?: boolean;
  /**
   * Per-model reasoning/effort catalog discovered by the daemon. Currently
   * populated for claude, codex, and opencode runtimes; omitted (or undefined)
   * for every other provider, which the UI treats as "no thinking-level
   * picker for this model". See MUL-2339.
   */
  thinking?: RuntimeModelThinking;
  /** Runtime-native execution tiers advertised for this exact model. */
  service_tiers?: RuntimeModelServiceTier[];
  /**
   * Whether this runtime's installed Codex CLI accepts the request-only
   * `default` sentinel for explicit standard routing. Missing means false so
   * a new client stays safe when connected to an older daemon.
   */
  supports_explicit_standard_service_tier?: boolean;
}

/**
 * A model the runtime named but will not run on that host — today only Claude
 * Code, reporting one that needs a newer CLI than the installed one.
 *
 * These arrive in their own list and never inside `models`, which is what keeps
 * an older client from offering one: it reads `models`, and they are not there.
 * The picker shows them greyed out with `reason` so the gap reads as "your CLI
 * is behind" rather than "Multica does not support this model" (MUL-6961).
 */
export interface RuntimeUnavailableModel {
  id: string;
  label: string;
  /** The runtime's own remedy, e.g. "Update to 2.1.255+ to use Fable 5.1". */
  reason?: string;
}

export interface RuntimeModelServiceTier {
  /** Catalog ID sent to the provider protocol unchanged. */
  id: string;
  /** Provider-owned display name, for example `Fast`. */
  name: string;
  /** Optional provider-owned helper copy. */
  description?: string;
}

export interface RuntimeModelThinking {
  /** Levels the user is allowed to pick for this model. */
  supported_levels: RuntimeModelThinkingLevel[];
  /** Informational: the level the upstream CLI documents as its built-in
   *  default when no `--effort` flag is passed. Surfaced by the daemon
   *  but not actively rendered today — Multica's empty `thinking_level`
   *  means "no override; let the local CLI config decide", which may
   *  itself differ from this value. */
  default_level?: string;
}

export interface RuntimeModelThinkingLevel {
  /** Runtime-native token passed to the CLI; never normalised. */
  value: string;
  /** Display label matching each CLI's own UI (`Low`, `Extra high`, …). */
  label: string;
  /** Optional helper copy lifted from upstream catalog
   *  (`codex debug models` emits one per level). */
  description?: string;
}

export type RuntimeModelListStatus =
  | "pending"
  | "running"
  | "completed"
  | "failed"
  | "timeout";

export interface RuntimeModelListRequest {
  id: string;
  runtime_id: string;
  status: RuntimeModelListStatus;
  models?: RuntimeModel[];
  /** Advisory rows the runtime cannot run; never selectable. */
  unavailable_models?: RuntimeUnavailableModel[];
  supported: boolean;
  error?: string;
  created_at: string;
  updated_at: string;
  /**
   * True when the server answered from its own catalog cache instead of a live
   * daemon round trip (MUL-5444). Informational only: such a response already
   * arrives with `status: "completed"` and a populated `models`, so callers
   * that ignore this field behave exactly as before. `cached_at` is the
   * snapshot's capture time.
   */
  cached?: boolean;
  cached_at?: string;
}

// Result shape returned by resolveRuntimeModels — includes the
// "supported" bit so the UI can distinguish "no models discovered"
// from "provider does not honour per-agent model selection".
export interface RuntimeModelsResult {
  models: RuntimeModel[];
  /**
   * Rows the runtime named but cannot run. Kept out of `models` on purpose —
   * see RuntimeUnavailableModel. Optional like `cached` beside it: the resolver
   * always sets it, but a backend older than the field contributes nothing, so
   * consumers read it defensively.
   */
  unavailableModels?: RuntimeUnavailableModel[];
  supported: boolean;
  /**
   * True when the server answered from its catalog cache rather than a live
   * daemon round trip (MUL-5444). Drives the query's freshness policy: a
   * cached answer is immediately revalidatable so the client never extends the
   * server's staleness window.
   */
  cached?: boolean;
  /** Capture time of the served snapshot, when the answer was cached. */
  cachedAt?: string;
}

export type RuntimeLocalSkillStatus =
  | "pending"
  | "running"
  | "completed"
  | "conflict"
  | "failed"
  | "timeout";

export type RuntimeLocalSkillImportAction = "overwrite";

export interface RuntimeLocalSkillImportConflict {
  existing_skill_id: string;
  existing_created_by?: string;
  can_overwrite: boolean;
}

export interface RuntimeLocalSkillSummary {
  key: string;
  name: string;
  description?: string;
  source_path: string;
  provider: string;
  /**
   * Which discovery root surfaced this skill: "provider" for the runtime's
   * own skill directory (e.g. ~/.claude/skills) or "universal" for the
   * cross-tool ~/.agents/skills fallback. Daemons that predate multi-root
   * discovery omit the field; treat `undefined` as unknown rather than
   * asserting either origin.
   */
  root?: "provider" | "universal" | "plugin";
  /** Enabled runtime plugin that contributed this skill, when applicable. */
  plugin?: string;
  /** New daemons set this only when they can enforce per-agent disablement. */
  can_disable?: boolean;
  file_count: number;
}

export interface RuntimeLocalMcpServerSummary {
	name: string;
	transport?: "stdio" | "http" | "sse" | "unknown";
	source?: string;
	enabled: boolean;
}

export interface RuntimeLocalSkillListRequest {
  id: string;
  runtime_id: string;
  status: RuntimeLocalSkillStatus;
  skills?: RuntimeLocalSkillSummary[];
  supported: boolean;
	mcp_servers?: RuntimeLocalMcpServerSummary[];
	mcp_supported?: boolean;
  error?: string;
  created_at: string;
  updated_at: string;
}

export interface CreateRuntimeLocalSkillImportRequest {
  skill_key: string;
  name?: string;
  description?: string;
  action?: RuntimeLocalSkillImportAction;
  target_skill_id?: string;
  supports_conflict?: boolean;
}

export interface RuntimeLocalSkillImportRequest {
  id: string;
  runtime_id: string;
  skill_key: string;
  name?: string;
  description?: string;
  action?: RuntimeLocalSkillImportAction;
  target_skill_id?: string;
  supports_conflict?: boolean;
  status: RuntimeLocalSkillStatus;
  skill?: Skill;
  conflict?: RuntimeLocalSkillImportConflict;
  error?: string;
  created_at: string;
  updated_at: string;
}

export interface RuntimeLocalSkillsResult {
  skills: RuntimeLocalSkillSummary[];
  supported: boolean;
	mcpServers: RuntimeLocalMcpServerSummary[];
	mcpSupported: boolean;
}

export interface RuntimeLocalSkillImportResult {
  status: "created" | "updated" | "conflict";
  skill?: Skill;
  conflict?: RuntimeLocalSkillImportConflict;
}
