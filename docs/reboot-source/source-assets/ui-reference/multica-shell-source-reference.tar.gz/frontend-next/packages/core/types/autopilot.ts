export type AutopilotStatus = "active" | "paused" | "archived";

export type AutopilotExecutionMode = "create_issue" | "run_only";

// `assignee_type` selects which polymorphic actor backs the autopilot:
// "agent" → assignee_id references agent(id); "squad" → assignee_id references
// squad(id) and dispatch resolves to squad.leader_id at run time (MUL-2429,
// Path A). Older servers omit this field — callers should default to "agent".
export type AutopilotAssigneeType = "agent" | "squad";

export type AutopilotTriggerKind = "schedule" | "webhook" | "api";

// `skipped` is emitted by the backend pre-flight admission check
// (assignee runtime offline at dispatch time, MUL-1899). The frontend MUST
// handle it explicitly — falling through to a generic case used to show
// the run as still-pending which masked the no-op.
export type AutopilotRunStatus =
  | "issue_created"
  | "running"
  | "completed"
  | "failed"
  | "skipped";

export type AutopilotRunSource = "schedule" | "manual" | "webhook" | "api";

export interface Autopilot {
  id: string;
  workspace_id: string;
  title: string;
  description: string | null;
  project_id?: string | null;
  assignee_type: AutopilotAssigneeType;
  assignee_id: string;
  status: AutopilotStatus;
  // Additive machine-readable explanation for a system pause. Null for manual
  // pauses and older servers.
  pause_reason?: string | null;
  execution_mode: AutopilotExecutionMode;
  issue_title_template: string | null;
  created_by_type: string;
  created_by_id: string;
  last_run_at: string | null;
  created_at: string;
  updated_at: string;
  // List-endpoint-only derived fields; absent on detail/create/update
  // responses and on older servers. Enabled triggers only. `trigger_kinds`
  // and `last_run_status` are server-driven strings — render unknown values
  // through a generic fallback, never an exhaustive switch.
  trigger_kinds?: string[];
  next_run_at?: string | null;
  last_run_status?: string | null;
  // List endpoint returns []; only the detail endpoint populates this.
  // Treat undefined as empty on older servers.
  subscribers?: AutopilotSubscriber[];
  // Whether the requesting user may edit / delete / trigger / manage this
  // autopilot (creator, workspace owner/admin, or a granted collaborator).
  // Present on list and detail responses; absent on older servers — treat
  // undefined as "unknown" rather than "denied" (the server is the gate).
  can_write?: boolean;
  // Whether the requesting user may manage the collaborator (access) list —
  // narrower than can_write: held only by the creator and workspace
  // owners/admins, NOT by granted collaborators. Detail-endpoint-only; absent
  // on older servers (fall back to can_write).
  can_manage_access?: boolean;
}

export interface WebhookEventFilter {
  event: string;
  actions?: string[];
}

export interface AutopilotSubscriber {
  user_type: "member";
  user_id: string;
  created_at: string;
}

// A workspace member explicitly granted write access to an autopilot, on top
// of the implicit "creator ∪ owner/admin" set. Members-only for now.
export interface AutopilotCollaborator {
  user_type: "member";
  user_id: string;
  granted_by: string;
  created_at: string;
}

export interface AutopilotCollaboratorsResponse {
  collaborators: AutopilotCollaborator[];
}

export interface AutopilotTrigger {
  id: string;
  autopilot_id: string;
  kind: AutopilotTriggerKind;
  enabled: boolean;
  cron_expression: string | null;
  timezone: string | null;
  next_run_at: string | null;
  webhook_token: string | null;
  // webhook_path is computed server-side from webhook_token (always
  // "/api/webhooks/autopilots/{token}"). Optional so older servers can be
  // talked to gracefully.
  webhook_path?: string | null;
  // webhook_url is only present when MULTICA_PUBLIC_URL is configured
  // server-side. Clients fall back to composing from getBaseUrl/origin +
  // webhook_path when this is missing.
  webhook_url?: string | null;
  label: string | null;
  // event_filters is only present for webhook triggers. Null/empty means
  // "accept all events".
  event_filters?: WebhookEventFilter[] | null;
  last_fired_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface AutopilotRun {
  id: string;
  autopilot_id: string;
  trigger_id: string | null;
  source: AutopilotRunSource;
  status: AutopilotRunStatus;
  issue_id: string | null;
  task_id: string | null;
  triggered_at: string;
  completed_at: string | null;
  failure_reason: string | null;
  // Stable, localizable, enumeration-safe classification of a non-success run
  // (skipped/failed), persisted at the server-side decision source. The
  // "run now" UI localizes this instead of echoing the raw English reason.
  // Older servers omit it.
  reason_code?: string;
  trigger_payload: unknown;
  result: unknown;
  created_at: string;
}

export interface AutopilotQuotaUsage {
  action: "off" | "observe" | "enforce";
  used: number | null;
  reserved: number | null;
  total: number | null;
  limit: number | null;
  reached: boolean | null;
  period_start: string | null;
  period_end: string | null;
  reset_at: string | null;
  blocked_counts: Record<string, number> | null;
}

export interface AutopilotSubscriberInput {
  user_type: "member";
  user_id: string;
}

export interface CreateAutopilotRequest {
  title: string;
  description?: string;
  project_id?: string | null;
  // Optional on the wire — when omitted the server defaults to "agent" so
  // older clients keep working.
  assignee_type?: AutopilotAssigneeType;
  assignee_id: string;
  execution_mode: AutopilotExecutionMode;
  issue_title_template?: string;
  subscribers?: AutopilotSubscriberInput[];
}

export interface UpdateAutopilotRequest {
  title?: string;
  description?: string | null;
  project_id?: string | null;
  // Send `assignee_type` together with `assignee_id` whenever you change the
  // assignee — the server requires both for a type swap.
  assignee_type?: AutopilotAssigneeType;
  assignee_id?: string;
  status?: AutopilotStatus;
  execution_mode?: AutopilotExecutionMode;
  issue_title_template?: string | null;
  // When present, fully replaces the autopilot's subscriber template;
  // omit to leave it untouched.
  subscribers?: AutopilotSubscriberInput[];
}

export interface CreateAutopilotTriggerRequest {
  kind: AutopilotTriggerKind;
  cron_expression?: string;
  timezone?: string;
  label?: string;
  // event_filters is only meaningful for webhook triggers.
  event_filters?: WebhookEventFilter[];
}

export interface UpdateAutopilotTriggerRequest {
  enabled?: boolean;
  cron_expression?: string;
  timezone?: string;
  label?: string;
  // event_filters is only meaningful for webhook triggers.
  event_filters?: WebhookEventFilter[] | null;
}

export interface CronPreviewResponse {
  // Next occurrences as RFC3339 UTC timestamps, ascending. An empty array
  // means the expression never fires; `null` is the client-side sentinel for
  // "the response could not be read" (schema drift), which callers must not
  // present as "never fires".
  next_runs: string[] | null;
}

export interface ListAutopilotsResponse {
  autopilots: Autopilot[];
  total: number;
}

export interface GetAutopilotResponse {
  autopilot: Autopilot;
  triggers: AutopilotTrigger[];
  // Members explicitly granted write access. Absent on older servers — treat
  // undefined as an empty list.
  collaborators?: AutopilotCollaborator[];
}

export interface ListAutopilotRunsResponse {
  runs: AutopilotRun[];
  total: number;
}

// Webhook delivery enum is server-canonical. The frontend MUST `default`
// any switch on it to a generic fallback — see API Response Compatibility
// rules in CLAUDE.md. PR1 collapsed `skipped` into `dispatched` (the run
// itself carries the skip state); a future server may add new values.
export type WebhookDeliveryStatus =
  | "queued"
  | "dispatched"
  | "rejected"
  | "ignored"
  | "failed";

export type WebhookSignatureStatus =
  | "not_required"
  | "valid"
  | "invalid"
  | "missing";

export interface WebhookDelivery {
  id: string;
  workspace_id: string;
  autopilot_id: string;
  trigger_id: string;
  provider: string;
  event: string;
  dedupe_key: string | null;
  dedupe_source: string | null;
  signature_status: WebhookSignatureStatus;
  status: WebhookDeliveryStatus;
  attempt_count: number;
  dispatch_attempts: number;
  available_at: string;
  content_type: string | null;
  response_status: number | null;
  autopilot_run_id: string | null;
  replayed_from_delivery_id: string | null;
  error: string | null;
  reason_code: string | null;
  replay_idempotency_key: string | null;
  received_at: string;
  last_attempt_at: string;
  created_at: string;
  // Detail-only fields. The list endpoint omits these to keep the wire
  // size bounded (raw_body alone can be up to 256 KiB per delivery).
  selected_headers?: Record<string, unknown> | null;
  raw_body?: string | null;
  response_body?: string | null;
}

export interface ListWebhookDeliveriesResponse {
  deliveries: WebhookDelivery[];
  total: number;
}
